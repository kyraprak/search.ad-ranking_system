from flask import Flask, render_template
from search_ranking import ads, rank_ads

app = Flask(__name__)

@app.route("/")
def index():
    ranked = rank_ads(ads)
    return render_template("index.html", ads=ranked)

if __name__ == "__main__":
    app.run(debug=True)
