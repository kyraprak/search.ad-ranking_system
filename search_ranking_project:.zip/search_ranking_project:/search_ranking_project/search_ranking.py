# search_ranking.py

ads = [
    {"id": 1, "advertiser": "Nike", "bid": 5.0, "relevance": 0.9},
    {"id": 2, "advertiser": "Apple", "bid": 6.0, "relevance": 0.7},
    {"id": 3, "advertiser": "Amazon", "bid": 4.5, "relevance": 0.95},
]

def rank_ads(ads_list):
    """Rank ads using simple formula: bid * relevance"""
    return sorted(
        ads_list,
        key=lambda ad: ad["bid"] * ad["relevance"],
        reverse=True
    )
